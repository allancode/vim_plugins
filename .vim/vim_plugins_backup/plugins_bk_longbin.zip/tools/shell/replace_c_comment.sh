#! /bin/sed -f
## Longbin <beangr@163.com>
## 2015-05-28

function awk_replace_comment()
{
	cat $* | awk 'BEGIN{RS=""} {gsub(/\/\*[^*]*\*+([^/*][^*]*\*+)*\//, " ", $0); gsub(/\/\/[^\n]*/, "", $0); print $0}'
}

if [ ${#} -ne 1 ] ;then
	echo "Only one file every time."
	exit
else
	awk_replace_comment $*
fi
