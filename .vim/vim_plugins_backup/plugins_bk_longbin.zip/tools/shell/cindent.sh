#! /bin/bash
## /usr/src/kernels/2.6.32-504.el6.i686/scripts/Lindent
## Author:			longbin <beangr@163.com>
## Release Date:	2015-05-28
## Release Version:	1.15.530
## Last Modified:	2015-05-30
##

# PARAM="-npro -kr -i8 -ts8 -sob -l80 -ss -ncs -cp1"
DEFAULT_STYLE_PARAM="-npro -kr -i8 -ts8 -sob -l80 -ss -ncs -cp1"
LINUX_STYLE_PARAM="-npro -nbad -bap -nbc -bbo -hnl -br -brs -c33 -cd33 -ncdb -ce -ci4 -cli0 -d0 -di1 -nfc1 -i8 -ip0 -l80 -lp -npcs -nprs -npsl -sai -saf -saw -ncs -nsc -sob -nfca -cp33 -ss -ts8 -il1"
GNU_STYLE_PARAM="-npro -nbad -bap -nbc -bbo -bl -bli2 -bls -ncdb -nce -cp1 -cs -di2 -ndj -nfc1 -nfca -hnl -i2 -ip5 -lp -pcs -nprs -psl -saf -sai -saw -nsc -nsob"
KR_STYLE_PARAM="-npro -nbad -bap -bbo -nbc -br -brs -c33 -cd33 -ncdb -ce -ci4 -cli0 -cp33 -cs -d0 -di1 -nfc1 -nfca -hnl -i4 -ip0 -l75 -lp -npcs -nprs -npsl -saf -sai -saw -nsc -nsob -nss"
VS_STYLE_PARAM="-npro -kr -i8 -ts8 -sob -l80 -ss -ncs -bl -bli0 -nce -bls -blf -bap -cp1 -npsl"
MY_STYLE_PARAM="-npro -kr -i8 -ts8 -sob -l80 -ss -ncs -br -ce -cdw -brs -brf -bap -cp1 -npsl"

INDENT_PARAM="${DEFAULT_STYLE_PARAM}"
FILE_TAIL=kr
## function check whether indent exists
function check_which_indent()
{
	local ret_val=$(which indent 2>/dev/null)
	if [ "x${ret_val}" == "x" ] ;then
		echo "ERR (127): Please install indent"
		exit 127
	fi
}
check_which_indent

## function indent function usage
function indent_func_usage()
{
	cat << EOF
Usage:
	bash ${0##*/} input_file1.c [input_file2.c ...]

	You will get new file(s): input_file1.c
	and the old file will backup to input_file1.c~

EOF
}

## function select indent style and parameters
function select_indent_style()
{
	echo "Please select indent style: "
	# TMOUT=5

	PS3="Type a index number[1]: "
	select option in \
		"DEFAULT STYLE" \
		"LINUX STYLE" \
		"GNU STYLE" \
		"KR STYLE" \
		"VS STYLE" \
		"MY STYLE"
	do
		case ${REPLY} in
		1)
			INDENT_PARAM="${DEFAULT_STYLE_PARAM}"
			FILE_TAIL=def
			;;
		2)
			INDENT_PARAM="${LINUX_STYLE_PARAM}"
			FILE_TAIL=linux
			;;
		3)
			INDENT_PARAM="${GNU_STYLE_PARAM}"
			FILE_TAIL=gnu
			;;
		4)
			INDENT_PARAM="${KR_STYLE_PARAM}"
			FILE_TAIL=kr
			;;
		5)
			INDENT_PARAM="${VS_STYLE_PARAM}"
			FILE_TAIL=vs
			;;
		6)
			INDENT_PARAM="${MY_STYLE_PARAM}"
			FILE_TAIL=my
			;;
		*)
			echo "invalid option."
			;;
		esac

		if [ "x${INDENT_PARAM}" != "x" ] ;then
			break
		fi
	done
	INDENT_PARAM="${INDENT_PARAM:=${DEFAULT_STYLE_PARAM}}"
}

##function set indent parameters
function set_indent_parameters()
{
	read -p "Press <Enter> to continue, or y to set indent style " select
	if [ "x${select}" == "xy" ] ;then
		select_indent_style
	fi

	INDENT_REV=$(indent --version)
	INDENT_REV_1=$(echo ${INDENT_REV} | cut -d' ' -f3 | cut -d'.' -f1)
	INDENT_REV_2=$(echo ${INDENT_REV} | cut -d' ' -f3 | cut -d'.' -f2)
	INDENT_REV_3=$(echo ${INDENT_REV} | cut -d' ' -f3 | cut -d'.' -f3)
	
	if [ ${INDENT_REV_1} -gt 2 ] ; then
		INDENT_PARAM="${INDENT_PARAM} -il0"
	elif [ ${INDENT_REV_1} -eq 2 ] ; then
		if [ ${INDENT_REV_2} -gt 2 ] ; then
			INDENT_PARAM="${INDENT_PARAM} -il0" 
		elif [ ${INDENT_REV_2} -eq 2 ] ; then
			if [ ${INDENT_REV_3} -ge 10 ] ; then
				INDENT_PARAM="${INDENT_PARAM} -il0"
			fi
		fi
	fi
	if [ "x${INDENT_PARAM}" != "x" ] ;then
		echo "Set indent parameter OK!"
	fi
}

## indent file main function
function indent_file_main_func()
{
	if [ ${#} -lt 1 ] ;then
		echo "ERR: No input file(s)"
		indent_func_usage
		exit
	elif [ ${#} -gt 1 ] ;then
		set_indent_parameters
		echo "Begin to format files ..."
		# indent ${INDENT_PARAM} $* -v
		indent ${INDENT_PARAM} $*
		if [ $? -eq 0 ] ;then
			echo "All files have been indented OK !"
			read -p "Delete old files <y/n>? " select
			if [ "x${select}" == "xy" ] ;then
				for file in $*
				do
					rm -v ${file}~
				done
			fi
			echo "Work done !"
		fi
	else

		if ! [ -f ${1} -a -r ${1} ] ;then
			echo "ERR: ${1} No such file or No permission to read"
			exit
		fi
	
		set_indent_parameters
	
		# read -p "Output to standard output(OR will overwrite the file) <y/n>? [n] " select
		if [ "x${select}" == "xy" ] ;then
			INDENT_PARAM="${INDENT_PARAM} -st"
			indent ${INDENT_PARAM} $1
		else
			INDENT_RESULT_FILE=${1%.*}_${FILE_TAIL}.c
			if [ -f ${INDENT_RESULT_FILE} ] ;then
				echo "ERR: ${INDENT_RESULT_FILE} already exists."
				exit
			fi
			indent ${INDENT_PARAM} $1 -o ${INDENT_RESULT_FILE}
			if [ $? -eq 0 ] ;then
				echo "Have written to file"
			else
				echo "ERR Occurred !"
				exit
			fi
			mv ${INDENT_RESULT_FILE} $1
			echo "Done !"
		fi

	fi
}
## indent [INDENT_PARAM] inputfiles
## indent [INDENT_PARAM] inputfile -o outputfile
## indent [INDENT_PARAM] inputfile -st > outputfile

indent_file_main_func $*
